package com.satyam.creationalPatterns.abstractFactory;

public interface Checkbox {
    void paint();
}
