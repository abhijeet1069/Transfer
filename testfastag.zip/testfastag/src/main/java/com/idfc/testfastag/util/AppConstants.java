package com.idfc.testfastag.util;

public interface AppConstants {
	
	int LOG_DEBUG = 0;
	int LOG_INFO = 1;
	int LOG_WARN = 2;
	int LOG_ERROR = 3;
	public final String EMPTY="";
}
