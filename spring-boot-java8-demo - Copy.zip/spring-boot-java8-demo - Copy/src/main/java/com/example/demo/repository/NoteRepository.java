package com.example.demo.repository;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class NoteRepository {
	
	private final JdbcTemplate jdbcTemplate;
	
	public NoteRepository(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<String> findAll(){
		return (List<String>) jdbcTemplate.query("SELECT message FROM notes", 
				(rs,rowNum)->rs.getString("message"));
	}
}
