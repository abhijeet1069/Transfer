package com.satyam.creationalPatterns.abstractFactory;

public interface Button {
    void paint();
}
