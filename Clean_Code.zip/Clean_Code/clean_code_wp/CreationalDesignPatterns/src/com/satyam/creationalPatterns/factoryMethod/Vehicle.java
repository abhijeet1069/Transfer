package com.satyam.creationalPatterns.factoryMethod;

public interface Vehicle {
	void start();
}
