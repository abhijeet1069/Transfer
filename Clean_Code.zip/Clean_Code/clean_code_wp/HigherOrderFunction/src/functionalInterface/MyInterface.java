package functionalInterface;

@FunctionalInterface
public interface MyInterface {
	void sayHello();
}
