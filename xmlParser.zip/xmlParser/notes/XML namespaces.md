# XML name spaces

Name conflicts in XML can be resolved by using a prefix.
When using prefixes in xml, a namespace for the prefix must be defined.
It can be defined by an xmlns attribute in start of an element, or root.

xml:prefix="URL"

```xml

<root
xmlns:h="http://www.w3.org/TR/html4/"
xmlns:f="http://www.w3.org/furniture">

<h:table>
	<h:tr>
		<h:td>Apples</h:td>
		<h:td>Bananas</h:td>
	</h:tr>
<h:table>

<f:table>
	<f:name>African Coffee table</f:name>
	<f:width>80</f:width>
	<f:length>120</f:length>
</f:table>
</root>

```

## Default namespaces

Defining a default namespace for an element saves us from using prefixes in all the child elements.

```xml

<root>

<table xmlns="http://www.w3.org/TR/html4/">
	<tr>
		<td>Apples</td>
		<td>Bananas</td>
	</tr>
<table>

<table xmlns="http://www.w3.org/TR/html4/">
	<name>African Coffee table</name>
	<width>80</width>
	<length>120</length>
</table>
</root>

```


