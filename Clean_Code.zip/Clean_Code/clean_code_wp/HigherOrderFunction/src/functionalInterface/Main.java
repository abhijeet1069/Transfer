package functionalInterface;

public class Main implements MyInterface{

	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		
	}

}
