package designPatterns.creational.abstractFactory;

public interface Button {
    void paint();
}
