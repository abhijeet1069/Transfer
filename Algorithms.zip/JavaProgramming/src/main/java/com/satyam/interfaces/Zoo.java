package com.satyam.interfaces;

interface Herbivore{
	void eatPlants();
}

interface Carnivore{
	void eatMeat();
}

public class Zoo {

}
