package graphics2d.bufferredImage;

import javax.swing.JPanel;

public class GamePanel extends JPanel{
	private BufferredImage;
	
}
