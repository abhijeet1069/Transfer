package com.idfc.testfastag.hostResponseBeans.gcust;

public class VehicleDetails {
	private String customerName;
	private String customerId;
	private String dob;
	private String emailId;
	private String kycFlag;
	private String custType;
	private String vrn;
	private String tagId;
	private String vehicleClass;
	private String vehicleClassDesc;
	private String status;
	private String avlblBalance;
	private String exempt;
	private String exemptCategory;
	private String comVehicle;
	private String issueDt;
	private String activationDt;
	private String accntNum;
	private String closeDt;
	private String maxRechargeLimit;
	private String avlblRechargeLimit;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getKycFlag() {
		return kycFlag;
	}
	public void setKycFlag(String kycFlag) {
		this.kycFlag = kycFlag;
	}
	public String getCustType() {
		return custType;
	}
	public void setCustType(String custType) {
		this.custType = custType;
	}
	public String getVrn() {
		return vrn;
	}
	public void setVrn(String vrn) {
		this.vrn = vrn;
	}
	public String getTagId() {
		return tagId;
	}
	public void setTagId(String tagId) {
		this.tagId = tagId;
	}
	public String getVehicleClass() {
		return vehicleClass;
	}
	public void setVehicleClass(String vehicleClass) {
		this.vehicleClass = vehicleClass;
	}
	public String getVehicleClassDesc() {
		return vehicleClassDesc;
	}
	public void setVehicleClassDesc(String vehicleClassDesc) {
		this.vehicleClassDesc = vehicleClassDesc;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAvlblBalance() {
		return avlblBalance;
	}
	public void setAvlblBalance(String avlblBalance) {
		this.avlblBalance = avlblBalance;
	}
	public String getExempt() {
		return exempt;
	}
	public void setExempt(String exempt) {
		this.exempt = exempt;
	}
	public String getExemptCategory() {
		return exemptCategory;
	}
	public void setExemptCategory(String exemptCategory) {
		this.exemptCategory = exemptCategory;
	}
	public String getComVehicle() {
		return comVehicle;
	}
	public void setComVehicle(String comVehicle) {
		this.comVehicle = comVehicle;
	}
	public String getIssueDt() {
		return issueDt;
	}
	public void setIssueDt(String issueDt) {
		this.issueDt = issueDt;
	}
	public String getActivationDt() {
		return activationDt;
	}
	public void setActivationDt(String activationDt) {
		this.activationDt = activationDt;
	}
	public String getAccntNum() {
		return accntNum;
	}
	public void setAccntNum(String accntNum) {
		this.accntNum = accntNum;
	}
	public String getCloseDt() {
		return closeDt;
	}
	public void setCloseDt(String closeDt) {
		this.closeDt = closeDt;
	}
	public String getMaxRechargeLimit() {
		return maxRechargeLimit;
	}
	public void setMaxRechargeLimit(String maxRechargeLimit) {
		this.maxRechargeLimit = maxRechargeLimit;
	}
	public String getAvlblRechargeLimit() {
		return avlblRechargeLimit;
	}
	public void setAvlblRechargeLimit(String avlblRechargeLimit) {
		this.avlblRechargeLimit = avlblRechargeLimit;
	}
	@Override
	public String toString() {
		return "VehicleDetails [customerName=" + customerName + ", customerId="
				+ customerId + ", dob=" + dob + ", emailId=" + emailId
				+ ", kycFlag=" + kycFlag + ", custType=" + custType + ", vrn="
				+ vrn + ", tagId=" + tagId + ", vehicleClass=" + vehicleClass
				+ ", vehicleClassDesc=" + vehicleClassDesc + ", status="
				+ status + ", avlblBalance=" + avlblBalance + ", exempt="
				+ exempt + ", exemptCategory=" + exemptCategory
				+ ", comVehicle=" + comVehicle + ", issueDt=" + issueDt
				+ ", activationDt=" + activationDt + ", accntNum=" + accntNum
				+ ", closeDt=" + closeDt + ", maxRechargeLimit="
				+ maxRechargeLimit + ", avlblRechargeLimit="
				+ avlblRechargeLimit + "]";
	}


}
