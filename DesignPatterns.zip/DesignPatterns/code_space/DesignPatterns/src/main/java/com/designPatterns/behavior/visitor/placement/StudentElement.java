package com.designPatterns.behavior.visitor.placement;

interface StudentElement {
	void accept(Visitor visitor);
}
