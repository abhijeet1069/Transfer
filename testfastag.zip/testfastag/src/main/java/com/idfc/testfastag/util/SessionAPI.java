package com.idfc.testfastag.util;

public class SessionAPI {
	
	public void addToLog(String log, int logLevel) {
		System.out.println(log);
	}

}
