package com.satyam.creationalPatterns.prototype;

public interface Prototype {
	Prototype clone();
}
