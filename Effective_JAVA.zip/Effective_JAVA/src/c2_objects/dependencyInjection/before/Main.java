package c2_objects.dependencyInjection.before;

class ClassA{
	ClassB classB = new ClassB();
	
	double tenPercent() {
		return classB.calculate()*0.1d;
	}
}

class ClassB{
	int amt = 100;
	
	public int calculate() {
		return amt;
	}
}

public class Main {
	public static void main(String[] args) {
		ClassA classA = new ClassA();
		System.out.println("Ten percent : "+classA.tenPercent());
	}
}
