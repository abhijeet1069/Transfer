package c2_objects.staticFactoryMethod;

/*

Static Factory Methods : A class can provide its clients with static factory methods instead of, or in
addition to, public constructors.

Use static factory methods over constructors : This acts an extra layer over constructors and can manipulate how we use them.
Also, it keeps constructor clean and does not violate single responsibility principle.
For ex: Singleton is a great example of a static factory method.


 * */

class User {
	private final String name;
	private final String email;
	private final String country;
	
	public User(String name, String email, String country) {
		this.name = name;
		this.email = email;
		this.country = country;
	}
	
	public static User createObjectWithDefaultEmail(String name, String country) { //static factory method
		return new User(name,null,country);
	}
	
	public String toString() {
		String str = String.format("Name : %s, Email : %s, Country : %s",name,email,country);
		return str;
	}
}


public class UserMain {

	public static void main(String[] args) {
		User medusa = User.createObjectWithDefaultEmail("Medusa", "Sarpedon Island");
		User zeus = new User("Zeus","zeus@invincible.com","Heaven");
		
		System.out.println(medusa.toString());
		System.out.println(zeus.toString());
	}
}