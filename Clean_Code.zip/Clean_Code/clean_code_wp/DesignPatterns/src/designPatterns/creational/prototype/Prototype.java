package designPatterns.creational.prototype;

public interface Prototype {
	Prototype clone();
}
