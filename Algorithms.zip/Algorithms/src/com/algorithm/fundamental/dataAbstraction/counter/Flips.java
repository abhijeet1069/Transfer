package com.algorithm.fundamental.dataAbstraction.counter;

import edu.princeton.cs.algs4.Counter;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class Flips {

	public static void main(String[] args) {
		
		int T = 2000;
		Counter heads = new Counter("heads");
		Counter tails = new Counter("tails");
		
		for(int t = 0; t < T; t++) {
			if(StdRandom.bernoulli(0.5))
				heads.increment();
			else
				tails.increment();
			}
		
			StdOut.println(heads);
			StdOut.println(tails);	
			int delta = heads.tally()-tails.tally();
			StdOut.println("Delta: "+Math.abs(delta));
	}
}
