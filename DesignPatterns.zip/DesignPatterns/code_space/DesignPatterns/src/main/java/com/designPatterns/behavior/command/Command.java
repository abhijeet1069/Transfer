package com.designPatterns.behavior.command;

public interface Command {
	void execute();
}
