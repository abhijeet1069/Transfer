const hummus = function(factor){
	const ingredient = function(amount,unit,name){
			let ingridientAmount = amount*factor;
			if(ingridientAmount > 1){
				unit += "s";
			}
			console.log(`${ingridientAmount} ${unit} ${name}`);
	};
		ingredient(1, "can", "chickpeas");
		ingredient(0.25, "cup", "tahini");
		ingredient(0.25, "cup", "lemon juice");
		ingredient(1, "clove", "garlic");
		ingredient(2, "tablespoon", "olive oil");
		ingredient(0.5, "teaspoon", "cumin");
	};

hummus(2);