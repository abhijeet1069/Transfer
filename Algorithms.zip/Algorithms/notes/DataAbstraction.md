# Data Abstraction

## Primitive Types

Java has 8 primitive types.
- byte
- short
- int
- long
- float
- double
- char
- boolean