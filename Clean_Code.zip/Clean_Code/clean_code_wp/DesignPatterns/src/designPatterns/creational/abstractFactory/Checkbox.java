package designPatterns.creational.abstractFactory;

public interface Checkbox {
    void paint();
}
