package cleanCode.smells.java.staticImport.good;

public class HttpConstants {
	private HttpConstants() {} // prevent instantiation
	public static final String GET = "GET";
}
