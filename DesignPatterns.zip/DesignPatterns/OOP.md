# Object Oriented Programming

Objects are not data structures. Objects may use data structures; but the manner in which those data structures are used or contained is hidden. 
This is why data fields are private. From the outside looking in you cannot see any state. All you can see are functions. Therefore Objects are 
about functions not about state.

Objects are bags of functions, not bags of data.