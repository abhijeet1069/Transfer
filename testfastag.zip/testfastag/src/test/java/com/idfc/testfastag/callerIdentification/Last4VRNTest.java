package com.idfc.testfastag.callerIdentification;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.idfc.testfastag.util.SessionAPI;

public class Last4VRNTest {

	ANICheck anicheck;
	SessionAPI sessionAPI;
	
	@Before
	public void setup() {
		anicheck = new ANICheck();
		sessionAPI = new SessionAPI();
	}
	
	@Test
	public void testLast4DigitsWithNormalVRN1() {
		String vrn = "MH90UI6743";
		assertEquals("6743",anicheck.getLastFourNumericDigits(sessionAPI,vrn));
	}
	
	@Test
	public void testLast4DigitsWithNormalVRN2() {
		String vrn = "FC00RM9051";
		assertEquals("9051",anicheck.getLastFourNumericDigits(sessionAPI,vrn));
	}
	
	@Test
	public void testLast4DigitsWithNormalVRN3() {
		String vrn = "HP39EP5559";
		assertEquals("5559",anicheck.getLastFourNumericDigits(sessionAPI,vrn));
	}
	
	@Test
	public void testLast4DigitsWithNormalVRN4() {
		String vrn = "DH01CU1023";
		assertEquals("1023",anicheck.getLastFourNumericDigits(sessionAPI,vrn));
	}
	
	@Test
	public void testLast4DigitsWithNormalVRN5() {
		String vrn = "MH90UI6743";
		assertEquals("6743",anicheck.getLastFourNumericDigits(sessionAPI,vrn));
	}
	
	@Test
	public void testLast4DigitsWithBharatVRN() {
		String vrn = "24BH7209B";
		assertEquals("7209",anicheck.getLastFourNumericDigits(sessionAPI,vrn));
	}
	
	@Test
	public void testLast4DigitsWithChasisNumber() {
		String vrn = "CHASSIS4567SISSAHC/9911";
		assertEquals("9911",anicheck.getLastFourNumericDigits(sessionAPI,vrn));
	}
	
}
