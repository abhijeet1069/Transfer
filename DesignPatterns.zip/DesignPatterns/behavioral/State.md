# State pattern

The State Pattern is a behavioral design pattern that allows an object to change its behavior when its internal state changes. It appears as if the object changed its class.