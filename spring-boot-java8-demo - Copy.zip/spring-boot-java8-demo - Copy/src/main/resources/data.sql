INSERT INTO notes(message)
VALUES('Fe Fi Fo Fum');