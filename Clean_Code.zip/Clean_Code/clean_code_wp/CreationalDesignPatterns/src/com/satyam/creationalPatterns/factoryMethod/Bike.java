package com.satyam.creationalPatterns.factoryMethod;

public class Bike implements Vehicle{

	@Override
	public void start() {
		System.out.println("Bike started");
	}
}
