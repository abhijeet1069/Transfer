/* function min(a,b){
	if(a < b)
		return a;
	else
		return b;
} */

/* function isEven(n){
	if(n == 0)
		return true;
	if(n == 1)
		return false;
	
	return(isEven(n-2));
}

console.log(isEven(50));
console.log(isEven(75));
console.log(isEven(-1)); */

/*  function multiplier(factor) {
	 function mult(number){
		return number*factor;
	 }
	 return mult;
}

let twice = multiplier(2);
console.log(twice(5)); //10 */

function countChar(str,ch) {
	 let ctr = 0;
	 for(let c of str){
		ctr += (c == ch) ? 1 : 0; 
	 }
	 return ctr;
}

function countBs(str){
	return countChar(str,"B")
	
}

console.log(countChar("kakkerlak", "k")); //4
console.log(countBs("BOB")); //2