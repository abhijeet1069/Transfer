processUserInput(greet);

function processUserInput(callback){
	const name = "Abhijeet";
	callback(name);
}

function greet(name){
	console.log("Hello "+name);
}