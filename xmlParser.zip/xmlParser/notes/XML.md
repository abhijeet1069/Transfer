# XML

## Root

XML must contain root element that is parent of all elements.

## XML Prolog

XML prolog is optional and is the first line.

```xml
<?xml version="1.0" encoding="UTF-8"?>
```

## Tags

All elements must have a closing tag. XML tags are case sensetive.

## Attributes

Attributes must be quoted.

## Nesting

XML elements must be nested properly.

## Entity reference

Some characters have defined meaning in XML like < & > are used to define elements or tags.

```xml
<eligibility> age > 18 </eligibility> <!--Error-->

<eligibility> age &gt; 18 </eligibility>
```

& &amp;
< &lt;
> &gt;
" &quot;
' &apos

## Comments

<!-- Comments -->
<!-- invalid -- comment -->

## White Space

In XML whitespace is preserved.

## Well formed XML

An XML message or document that follows these rules and syntax will be a well formed xml



