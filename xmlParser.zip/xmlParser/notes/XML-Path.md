# XPath

XPath is a query language for navigating in XML documents.

For ex:
XPath :
/bookstore/book[2]/author - J.K.Rowling

/bookstore/book[2]/title/@lang - en

Online Tools : http://xpather.com/

```xml
<bookstore>
    
    <book category="cooking">
        <title lang="en">Everyday Italian</title>
        <author>Giada De Laurentiis</author>
        <year>2005</year>
        <price>30.00</price>
    </book>

    <book category="children">
        <title lang="en">Harry Potter</title>
        <author>J.K.Rowling</author>
        <year>2005</year>
        <price>29.99</price>
    </book>
    
</bookstore>
```

## Relative XPath

Absolute XPath : /bookstore/book[2]/author
Relative XPath : //*/book[2]/author