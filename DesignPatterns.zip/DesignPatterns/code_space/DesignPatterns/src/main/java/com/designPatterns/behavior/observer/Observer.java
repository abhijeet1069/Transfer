package com.designPatterns.behavior.observer;

public interface Observer {
	void update(String news);
}
