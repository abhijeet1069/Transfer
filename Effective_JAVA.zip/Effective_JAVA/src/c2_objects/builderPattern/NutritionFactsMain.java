package c2_objects.builderPattern;

class NutritionFacts{
	private final int servingSize; 	// (mL) required
	private final int servings; 	// (per container) required
	private final int calories; 	// (per serving) optional
	private final int fat; 			// (g/serving) optional
	private final int sodium; 		// (mg/serving) optional
	private final int carbohydrate; // (g/serving) optional
	
	public static class Builder{
		//required parameters
		private final int servingSize;
		private final int servings;
		
		//optional parameters-initialized to default values
		private int calories = 0;
		private int fat = 0;
		private int sodium = 0;
		private int carbohydrate = 0;
		
		public Builder(int servingSize, int servings) {
			this.servingSize = servingSize; // we can also incorporate validity checks here, such that user doesen't enter garbage value
			this.servings = servings;
		}
		
		public Builder calories(int val) {
			calories = val; //put validity checks if required
			return this;	
		}	
		public Builder fat(int val) {
			fat = val; 
			return this;	
		}
		public Builder sodium(int val) {
			sodium = val; 
			return this;	
		}
		public Builder carbohydrate(int val) {
			carbohydrate = val; 
			return this;	
		}
		
		public NutritionFacts build() {
			return new NutritionFacts(this);
		}
		
	}
	
	private NutritionFacts(Builder builder) {
		servingSize = builder.servingSize;
		servings = builder.servings;
		calories = builder.calories;
		fat = builder.fat;
		sodium = builder.sodium;
		carbohydrate = builder.carbohydrate;
	}
	
	public String toString() {
		String str = String.format("Serving size : %d, Servings : %d \nCalories : %d, Fat : %d, Sodium : %d, Carbohydrates : %d", servingSize,servings,calories,fat,sodium,carbohydrate);
		return str;
	}
}

public class NutritionFactsMain {
	
	public static void main(String[] args) {
		//named optional pattern is one of the most beautiful syntax I have seen
		NutritionFacts cocaCola = new NutritionFacts.Builder(1000, 2).calories(100).sodium(35).build(); //named optional pattern
		System.out.println(cocaCola.toString());
	}
}
