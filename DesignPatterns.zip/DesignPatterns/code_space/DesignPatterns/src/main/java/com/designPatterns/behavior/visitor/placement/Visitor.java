package com.designPatterns.behavior.visitor.placement;

public interface Visitor {
	void visit(Student student);
}
