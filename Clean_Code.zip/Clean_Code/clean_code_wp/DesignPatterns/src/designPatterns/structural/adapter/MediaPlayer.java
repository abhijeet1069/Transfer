package designPatterns.structural.adapter;

//target Interface
public interface MediaPlayer {
	void play(String audioType, String fileName);
}