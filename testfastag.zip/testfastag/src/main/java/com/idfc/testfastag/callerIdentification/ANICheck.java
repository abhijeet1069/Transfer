package com.idfc.testfastag.callerIdentification;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.idfc.testfastag.hostResponseBeans.gcust.Customer;
import com.idfc.testfastag.hostResponseBeans.gcust.Vehicle;
import com.idfc.testfastag.hostResponseBeans.gcust.VehicleDetails;
import com.idfc.testfastag.util.AppConstants;
import com.idfc.testfastag.util.SessionAPI;

public class ANICheck implements AppConstants{
	/**
	 * Returns last 4 characters of a current vehicle number. 
	 * @param fullVehicleNumber - Vehicle number from API
	 * */
	public String getLastFourNumericDigits(SessionAPI sessionAPI, String vehicleNumber) {
		String methodName = "getLastFourNumericDigits:: ";
		String result = EMPTY;
		if(vehicleNumber != null) {
			Pattern pattern = Pattern.compile("\\d");
			Matcher matcher = pattern.matcher(vehicleNumber);

			StringBuilder numericDigits = new StringBuilder();
			while (matcher.find()) {
				numericDigits.append(matcher.group());
			}

			if (numericDigits.length() >= 4) 
				result = numericDigits.substring(numericDigits.length() - 4);
			else 
				result =  numericDigits.toString();
		}
		sessionAPI.addToLog(methodName+"Vehicle number = "+vehicleNumber+ " Last 4 digits = "+result,LOG_DEBUG);
		return result;
	}
	
	/**
	 * Creates a HashMap with key as last4VRN and value as corresponding VehicleDetails
	 * @param apiCustList - customer list which API returned
	 * */
	public Map<String,VehicleDetails> getVehicleDetails(SessionAPI sessionAPI,List<Customer> apiCustList){
		String methodName = "getVehicleDetails:: ";
		Map<String,VehicleDetails> vehicleMap = new HashMap<String,VehicleDetails>();
		for(int i = 0; i < apiCustList.size() && apiCustList.get(i) != null; i++ ){
			List<Vehicle> vehicles = apiCustList.get(i).getVehicles();
			for(int j = 0; j < vehicles.size() && vehicles.get(j)!=null; j++){
				String vrn = vehicles.get(j).getVrn();
				VehicleDetails tempVehicle = new VehicleDetails();
				tempVehicle.setCustomerName(apiCustList.get(i).getCustomerName());
				tempVehicle.setCustomerId(apiCustList.get(i).getCustomerId());
				tempVehicle.setDob(apiCustList.get(i).getDob());
				tempVehicle.setEmailId(apiCustList.get(i).getEmailId());
				tempVehicle.setKycFlag(apiCustList.get(i).getKycFlag());
				tempVehicle.setCustType(apiCustList.get(i).getCustType());
				tempVehicle.setVrn(vrn);
				tempVehicle.setTagId(vehicles.get(j).getTagId());
				tempVehicle.setVehicleClass(vehicles.get(j).getVehicleClass());
				tempVehicle.setVehicleClassDesc(vehicles.get(j).getVehicleClassDesc());
				tempVehicle.setStatus(vehicles.get(j).getStatus());
				tempVehicle.setAvlblBalance(vehicles.get(j).getAvlblBalance());
				tempVehicle.setExempt(vehicles.get(j).getExempt());
				tempVehicle.setExemptCategory(vehicles.get(j).getExemptCategory());
				tempVehicle.setComVehicle(vehicles.get(j).getComVehicle());
				tempVehicle.setIssueDt(vehicles.get(j).getIssueDt());
				tempVehicle.setActivationDt(vehicles.get(j).getActivationDt());
				tempVehicle.setAccntNum(vehicles.get(j).getAccntNum());
				tempVehicle.setCloseDt(vehicles.get(j).getCloseDt());
				tempVehicle.setMaxRechargeLimit(apiCustList.get(i).getMaxRechargeLimit());
				tempVehicle.setAvlblRechargeLimit(apiCustList.get(i).getAvlblRechargeLimit());

				vehicleMap.put(getLastFourNumericDigits(sessionAPI,vrn),tempVehicle);
			}
		}
		sessionAPI.addToLog(methodName+" Vehicle Map :: "+vehicleMap,LOG_DEBUG);
		return vehicleMap;
	}
}
