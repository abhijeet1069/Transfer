package com.satyam.algorithms.bitwise;

public class FastMultDiv {
	
	public static int multBy2(int n) {
		return n << 1;
	}
	
	public static int divBy2(int n) {
		return n >> 1;
	}

}
