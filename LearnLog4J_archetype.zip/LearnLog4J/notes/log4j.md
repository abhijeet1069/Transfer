# Log4J 2

## Default configuration path

src/main/resources/log4j2.xml

## Logging levels

- Trace(600) : Least severe log levels. Low level details like variable values
- Debug(500) : Used to check whether an operation is being performed correctly.
- Info(400) : Record events like User authentication, API calls or DB access
- Warn(300) : Potential issues
- Error(200) : Record unexpected errors in program execution
- Fatal(100) : Application crash
 