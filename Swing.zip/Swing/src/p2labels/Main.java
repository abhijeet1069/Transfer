package p2labels;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class Main {

	public static void main(String[] args) {
		// JLabel - GUI display area for a string of text, an image or both
		
		JLabel label = new JLabel();
		label.setText("Bro, do you even code?");
		
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500,500);
		frame.setVisible(true);
		frame.add(label);
	}
}
