# Method Reference


Method references allows us to refer to a method without invoking it, making our code cleaner and more
readable. They can be used in place of a lambda expression when the lambda expression only calls an existing
method.
