package cleanCode.smells.java.staticImport.bad;

public class InvokeHost implements AppConstants{
	
	
	public static void invokeGetRequest() {
		System.out.println("Invoking "+GET+" request");
	}
	
	public static void main(String[] args) {
		invokeGetRequest();
	}
}
