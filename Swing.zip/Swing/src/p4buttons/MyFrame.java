package p4buttons;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyFrame extends JFrame implements ActionListener{
	
	JButton button;
	JLabel label;
	
	MyFrame(){	
		ImageIcon icon = new ImageIcon("C:\\Personal\\OpenSource\\Swing\\res\\thumbs-up.png");
		Image iconImage = icon.getImage();
		iconImage = iconImage.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
		icon = new ImageIcon(iconImage);
		
		ImageIcon icon2 = new ImageIcon("C:\\Personal\\OpenSource\\Swing\\res\\thanks.png");
		Image iconImage2 = icon2.getImage();
		iconImage2 = iconImage2.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		icon2 = new ImageIcon(iconImage2);
		
		label = new JLabel();
		label.setIcon(icon2);
		label.setBounds(150,250,150,150);
		label.setVisible(false);
		
		button = new JButton();
		button.setBounds(200,100,70,50);
		button.setText("Like");
		button.setFocusable(false);//removes rectangle around text in buttton
		button.setIcon(icon);
		button.setHorizontalTextPosition(JButton.CENTER);
		button.setVerticalTextPosition(JButton.BOTTOM);
		button.setFont(new Font("Comic Sans",Font.BOLD,12));
		button.setBorder(BorderFactory.createEtchedBorder());
		//button.setEnabled(false);
		//button.setIconTextGap(-15);
		//button.setForeground(Color.cyan);
		button.setBackground(Color.lightGray);
		button.addActionListener(this);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null); //Null layout manager
		this.setSize(500,500);
		this.setVisible(true);
		this.add(button);
		this.add(label);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == button) {
			System.out.println("Button clicked");
			label.setVisible(true);
		}
	}
}
