package com.satyam.interfacesAsTypes.animalTypes;

public interface Fish {
	public String TYPE = "FISH";
	public String getName();
	public String fact();
}
