//Clean this code. Place results in a hashmap and save results to a CSV file. Make a runnable jar
//with input as folder and xmlPath
//checkout how Servion is creating a hashmap in its sesionbuilder

	package com.satyam.xmlParser;

	import java.io.File;
	import java.io.IOException;

	import javax.xml.parsers.DocumentBuilder;
	import javax.xml.parsers.DocumentBuilderFactory;
	import javax.xml.parsers.ParserConfigurationException;
	import javax.xml.xpath.*;

	import org.w3c.dom.Document;
    import org.w3c.dom.NodeList;
	import org.xml.sax.SAXException;

    import java.nio.file.*;
	import java.nio.file.attribute.BasicFileAttributes;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;

	public class App{

		public static String[] getContentInXML(String xmlFile, String xmlPath) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {
			String[] res = null;
			try {
				File file = new File(xmlFile);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(file);

				XPathFactory xPathFactory = XPathFactory.newInstance();
				XPath xPath = xPathFactory.newXPath();
				XPathExpression xPathExpression = xPath.compile(xmlPath);

				NodeList nodeList = (NodeList) xPathExpression.evaluate(doc, XPathConstants.NODESET);
				res = new String[nodeList.getLength()];
				for(int i = 0 ;i < res.length; i++){
					res[i] = nodeList.item(i).getTextContent();
				}
			}
			catch(Exception e){
				throw e;
			}
			return res;
		}

		public static List<String> listFiles(String directoryPath) throws IOException {
			List<String> fileNames = new ArrayList<>();

			Files.walkFileTree(Paths.get(directoryPath), new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
					fileNames.add(file.toString());
					return FileVisitResult.CONTINUE;
				}

				@Override
				public FileVisitResult visitFileFailed(Path file, IOException exc) {
					System.err.println("Failed to access file: " + file.toString());
					return FileVisitResult.CONTINUE;
				}
			});
			Collections.sort(fileNames);
			return fileNames;
		}

		public static void main(String[] args) {
			try {

				//String xmlFile = "resources/xml_files/host/rest/IDFC_HA_HSM_0001.xml";
				String expression = "/host/settings/setting[@name=\"URL\"]";
				/**
				String[] res = getContentInXML(xmlFile,expression);

				for(String str : res){
					System.out.println(str);
				}
				 **/
				String xmlDirectory = "resources/xml_files/host/rest";
				List<String> res = listFiles(xmlDirectory);

				for(String xmlFile : res){
					String[] content = getContentInXML(xmlFile,expression);
					for(String str : content)
						System.out.println(str);
				}
				//System.out.println(res.size());
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
