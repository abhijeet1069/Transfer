package designPatterns.creational.factoryMethod;

public interface Vehicle {
	void start();
}
