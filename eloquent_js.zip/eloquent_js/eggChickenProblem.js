/**
JS returns below error if we exceed call stack size.
eggChickenProblem.js:10 Uncaught RangeError: Maximum call stack size exceeded
*/

function chicken(){
	return egg();
}

function egg(){
	return chicken();
}

console.log(chicken()+" came first.");