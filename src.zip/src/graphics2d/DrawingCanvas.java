package graphics2d;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

public class DrawingCanvas extends JComponent{
	
	private int width;
	private int height;
	private Cloud c1,c2,c3;
	
	public DrawingCanvas(int w, int h) {
		width = w;
		height = h;
		c1 = new Cloud(10,50,75,Color.LIGHT_GRAY);
		c2 = new Cloud(200,75,90,Color.BLUE);
		c3 = new Cloud(420,60,85,Color.DARK_GRAY);
	}
	
	@Override
	protected void paintComponent(Graphics g) { //paintComponent is called by JVM. No need to call it explicitly
		Graphics2D g2d = (Graphics2D)g;
		
		RenderingHints rh = new RenderingHints(
				RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
				
		g2d.setRenderingHints(rh); //anti-aliasing
		
		c1.drawCloud(g2d);
		c2.drawCloud(g2d);
		c3.drawCloud(g2d);
		
		/**
		Rectangle2D.Double r = new Rectangle2D.Double(0,0,width,height); //(x,y,width,height)
		g2d.setColor(new Color(100,149,237));
		g2d.fill(r);
		
		Ellipse2D.Double e = new Ellipse2D.Double(200,75,100,100); //(x,y,width,height)
		g2d.setColor(Color.BLUE);
		g2d.fill(e);
		
		Line2D.Double line = new Line2D.Double(100,250,300,75);
		g2d.setColor(Color.BLACK);
		g2d.draw(line);
		**/
	}
}
