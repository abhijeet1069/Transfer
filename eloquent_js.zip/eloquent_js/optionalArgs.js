/**
JavaScript is extremely broad-minded about the number of arguments you can pass to a function. 
If you pass too many, the extra ones are ignored. If you pass too few, the missing parameters are assigned 
the value undefined.
*/

function minus(a,b){
	if(b === undefined)
		return -a;
	else
		return a-b;
}

console.log(minus(4,true,"Fe Fi")); // 3
console.log(minus(10)); // -10
console.log(minus(10,5)); // 5
console.log(10,20,12,13,32,2); // 10 20 12 13 32 2