package com.satyam;

//target Interface
public interface MediaPlayer {
	void play(String audioType, String fileName);
}