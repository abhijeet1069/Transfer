package com.idfc.testfastag.callerIdentification;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.idfc.testfastag.hostResponseBeans.gcust.Customer;
import com.idfc.testfastag.hostResponseBeans.gcust.Response;
import com.idfc.testfastag.hostResponseBeans.gcust.VehicleDetails;
import com.idfc.testfastag.util.SessionAPI;

public class TestFastagCoreDS {
	
	ANICheck anicheck;
	SessionAPI sessionAPI;
	Map<String, VehicleDetails> vehicleMap;
	
	@Before
	public void setup() {
		anicheck = new ANICheck();
		sessionAPI = new SessionAPI();
		try {
			Gson gson = new GsonBuilder().serializeNulls().excludeFieldsWithoutExposeAnnotation().create();
			String hostResponse = new String(Files.readAllBytes(Paths.get("src/test/java/resources/gcust1.json")));
			Response apiResponse = gson.fromJson(hostResponse, Response.class); 
			List<Customer> apiCustList = apiResponse.getResponse().getCustomer();
			vehicleMap = anicheck.getVehicleDetails(sessionAPI, apiCustList);
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetVehicleDetails() {
		VehicleDetails vehicleDetails = vehicleMap.get("6743"); 
		// Replace with the last four digits logic 
		assertNotNull(vehicleDetails); 
		assertEquals("AKASH MAHESH PATIL", vehicleDetails.getCustomerName()); 
		assertEquals("MH90UI6743", vehicleDetails.getVrn());
	}
}
