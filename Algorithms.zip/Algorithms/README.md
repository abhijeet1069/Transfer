# Algorithms

Algorithm Design manual book by Steven S Skiena implemented in Java

## Topics to revisit

- monotonic stack : WTF is it?
- Doubly linked list
