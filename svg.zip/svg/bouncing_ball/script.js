const svg = document.getElementById("mySvg");
    const ball = document.getElementById("ball");

    const radius = parseFloat(ball.getAttribute("r"));

    // Ball state (vectors)
    let position = { x: 100, y: 100 };
    let velocity = { x: 3, y: 2 };

    const width = svg.width.baseVal.value;
    const height = svg.height.baseVal.value;

    function moveBall() {
      // Update position
      position.x += velocity.x;
      position.y += velocity.y;

      // Bounce on X edges
      if (position.x + radius >= width || position.x - radius <= 0) {
        velocity.x *= -1;
      }

      // Bounce on Y edges
      if (position.y + radius >= height || position.y - radius <= 0) {
        velocity.y *= -1;
      }

      // Apply new position
      ball.setAttribute("cx", position.x);
      ball.setAttribute("cy", position.y);

      requestAnimationFrame(moveBall);
    }

    moveBall();