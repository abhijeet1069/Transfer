/**
This feature—being able to reference a specific instance of a local binding in an enclosing scope—is called closure.
Because of the closure, count is not destroyed when makeCounter exits — it lives on inside the returned function.

Think of a closure as:
	An object without a class declaration.
	The function is the “method,” and the captured variables are its “private fields.”
	
A pure function is a specific kind of value-producing function that not only has no side effects but also doesn’t 
rely on side effects from other code—for example, it doesn’t read global bindings whose value might change. 
A pure function has the pleasant property that, when called with the same arguments, it always produces the same 
value (and doesn’t do anything else).
*/


/* function makeCounter() {
  let count = 0;
  return () => ++count;
}

const counter = makeCounter();
const counter1 = makeCounter(); 
const counter2 = makeCounter(); 
console.log(counter1()); // 1 
console.log(counter1()); // 2 
console.log(counter2()); // 1 (separate closure)
console.log(counter.count); // undefined
 */
 
 function multiplier(factor) {
  return number => number * factor;
}

let twice = multiplier(2);
console.log(twice(5)); //10