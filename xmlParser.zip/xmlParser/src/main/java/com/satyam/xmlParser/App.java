package com.satyam.xmlParser;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class App{
    public static void main(String[] args) {
    	try {
    	File xmlFile = new File("C:\\Personal\\code\\xmlParser\\resources\\xml_files\\host\\rest\\IDFC_HA_HSM_0001.xml");
    	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
    	Document doc = (Document) dBuilder.parse(xmlFile);
    	
    	//String tagName = "settings";
    	
    	Node root = doc.getDocumentElement().getFirstChild();
    	System.out.println(root.getNodeName());
    	
    	//System.out.println(doc.getDocumentElement().getNodeName());
    	//System.out.println(doc.getDocumentElement().getNodeValue());
    	//System.out.println(doc.getDocumentElement().getAttributes().item(0));
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    }
}
