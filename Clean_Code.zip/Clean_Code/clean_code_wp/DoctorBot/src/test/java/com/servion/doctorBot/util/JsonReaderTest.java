package com.servion.doctorBot.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JsonReaderTest {

	@Test
	void testReadJSON() {
		fail("Not yet implemented");
	}

}
