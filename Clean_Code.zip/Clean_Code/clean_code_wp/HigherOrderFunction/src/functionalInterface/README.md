# Functional Interface

Interfaces having exactly single abstract method but can have any number of defaults and static methods. 
	We can invoke a lambda expression by using functional interface.