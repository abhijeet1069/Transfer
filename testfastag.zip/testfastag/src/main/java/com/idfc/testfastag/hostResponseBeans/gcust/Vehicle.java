package com.idfc.testfastag.hostResponseBeans.gcust;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Vehicle {
	@SerializedName("vrn")
    @Expose
	private String vrn;
    
	@SerializedName("tagId")
    @Expose
	private String tagId;
	
	@SerializedName("vehicleClass")
    @Expose
	private String vehicleClass;
    
	@SerializedName("vehicleClassDesc")
    @Expose
	private String vehicleClassDesc;
    
	@SerializedName("status")
    @Expose
	private String status;
    
	@SerializedName("avlblBalance")
    @Expose
	private String avlblBalance;
    
	@SerializedName("exempt")
    @Expose
	private String exempt;
    
	@SerializedName("exemptCategory")
    @Expose
	private String exemptCategory;
    
	@SerializedName("comVehicle")
    @Expose
	private String comVehicle;
    
	@SerializedName("issueDt")
    @Expose
	private String issueDt;
    
	@SerializedName("activationDt")
    @Expose
	private String activationDt;
    
	@SerializedName("accntNum")
    @Expose
	private String accntNum;
    
	@SerializedName("closeDt")
    @Expose
	private String closeDt;

	public String getVrn() {
		return vrn;
	}

	public void setVrn(String vrn) {
		this.vrn = vrn;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public String getVehicleClass() {
		return vehicleClass;
	}

	public void setVehicleClass(String vehicleClass) {
		this.vehicleClass = vehicleClass;
	}

	public String getVehicleClassDesc() {
		return vehicleClassDesc;
	}

	public void setVehicleClassDesc(String vehicleClassDesc) {
		this.vehicleClassDesc = vehicleClassDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAvlblBalance() {
		return avlblBalance;
	}

	public void setAvlblBalance(String avlblBalance) {
		this.avlblBalance = avlblBalance;
	}

	public String getExempt() {
		return exempt;
	}

	public void setExempt(String exempt) {
		this.exempt = exempt;
	}

	public String getExemptCategory() {
		return exemptCategory;
	}

	public void setExemptCategory(String exemptCategory) {
		this.exemptCategory = exemptCategory;
	}

	public String getComVehicle() {
		return comVehicle;
	}

	public void setComVehicle(String comVehicle) {
		this.comVehicle = comVehicle;
	}

	public String getIssueDt() {
		return issueDt;
	}

	public void setIssueDt(String issueDt) {
		this.issueDt = issueDt;
	}

	public String getActivationDt() {
		return activationDt;
	}

	public void setActivationDt(String activationDt) {
		this.activationDt = activationDt;
	}

	public String getAccntNum() {
		return accntNum;
	}

	public void setAccntNum(String accntNum) {
		this.accntNum = accntNum;
	}

	public String getCloseDt() {
		return closeDt;
	}

	public void setCloseDt(String closeDt) {
		this.closeDt = closeDt;
	}

	@Override
	public String toString() {
		return "Vehicle [vrn=" + vrn + ", tagId=" + tagId + ", vehicleClass=" + vehicleClass + ", vehicleClassDesc="
				+ vehicleClassDesc + ", status=" + status + ", avlblBalance=" + avlblBalance + ", exempt=" + exempt
				+ ", exemptCategory=" + exemptCategory + ", comVehicle=" + comVehicle + ", issueDt=" + issueDt
				+ ", activationDt=" + activationDt + ", accntNum=" + accntNum + ", closeDt=" + closeDt + "]";
	}
}
