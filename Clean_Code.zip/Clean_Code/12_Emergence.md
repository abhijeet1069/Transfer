# Emergence

## Getting clean via emergent designs

If we follow below principles, then good design starts to emerge

- Runs all the tests
- Contains no duplication
- Expresses the intent of the programmer
- Minimizes the number of classes and methods
