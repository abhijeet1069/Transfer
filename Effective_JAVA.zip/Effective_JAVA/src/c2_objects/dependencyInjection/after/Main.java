package c2_objects.dependencyInjection.after;

//Dependency Injection : Constructor Injection

class ClassA{
	
	ClassB classB;
	
	ClassA(ClassB injected){
		classB = injected;
	}
	
	double tenPercent() {
		return classB.calculate()*0.1d;
	}
}

class ClassB{
	int amt = 100;
	
	public int calculate() {
		return amt;
	}
}

public class Main {
	
	public static void main(String[] args) {
		
		ClassB classB = new ClassB();
		ClassA classA = new ClassA(classB);
		
		System.out.println("Ten Precent: "+classA.tenPercent());
		
	}
}
