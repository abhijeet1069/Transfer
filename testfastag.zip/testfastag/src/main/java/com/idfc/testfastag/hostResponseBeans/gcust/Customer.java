package com.idfc.testfastag.hostResponseBeans.gcust;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Customer {
	@SerializedName("customerName")
    @Expose
	private String customerName;
    
	@SerializedName("customerId")
    @Expose
	private String customerId;
    
	@SerializedName("dob")
    @Expose
	private String dob;
    
	@SerializedName("emailId")
    @Expose
	private String emailId;
    
	@SerializedName("kycFlag")
    @Expose
	private String kycFlag;
    
	@SerializedName("custType")
    @Expose
	private String custType;
    
	@SerializedName("vehicles")
    @Expose
	private List<Vehicle> vehicles;
    
	@SerializedName("maxRechargeLimit")
    @Expose
	private String maxRechargeLimit;
    
	@SerializedName("avlblRechargeLimit")
    @Expose
	private String avlblRechargeLimit;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getKycFlag() {
		return kycFlag;
	}

	public void setKycFlag(String kycFlag) {
		this.kycFlag = kycFlag;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public String getMaxRechargeLimit() {
		return maxRechargeLimit;
	}

	public void setMaxRechargeLimit(String maxRechargeLimit) {
		this.maxRechargeLimit = maxRechargeLimit;
	}

	public String getAvlblRechargeLimit() {
		return avlblRechargeLimit;
	}

	public void setAvlblRechargeLimit(String avlblRechargeLimit) {
		this.avlblRechargeLimit = avlblRechargeLimit;
	}

	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerId=" + customerId + ", dob=" + dob + ", emailId="
				+ emailId + ", kycFlag=" + kycFlag + ", custType=" + custType + ", vehicles=" + vehicles
				+ ", maxRechargeLimit=" + maxRechargeLimit + ", avlblRechargeLimit=" + avlblRechargeLimit + "]";
	}
}
