package com.idfc.testfastag.hostResponseBeans.gcust;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("response")
    @Expose
    private GCustResponse response;

    // Getters and Setters
    public GCustResponse getResponse() {
        return response;
    }

    public void setResponse(GCustResponse response) {
        this.response = response;
    }
}

