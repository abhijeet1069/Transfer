# XML DOM

DOM represents the content of xml or html document as tree structure, which we can then
use to easily read, access and update the contents of the document.

D : Document - File 
O : Object - Object
M : Model - Layout structure

```xml

<books>
	<book>
		<author>Carson</author>
		<price format="dollar">31.95</price>
		<pubdate>01/01/2002</pubdate>
	</book>
	<pubinfo>
		<publisher>MSPress</publisher>
		<state>WA</state>
	</pubinfo>
</books>

```