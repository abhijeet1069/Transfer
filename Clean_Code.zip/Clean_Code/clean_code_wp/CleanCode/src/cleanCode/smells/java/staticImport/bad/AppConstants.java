package cleanCode.smells.java.staticImport.bad;

public interface AppConstants {
	public final String GET = "GET";
}
