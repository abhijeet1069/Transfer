# Memory Leaks in JAVA

## Causes of memory leaks in JAVA

- Excessive use of static members
	Static members tend to exist throughout the lifetime of application and tend 	not to be garbage collected.
- Unclosed resources
- Improper equals() and hashCode() implementations
- Excessive session objects
- Poorly written custom data structure

## Memory leaks in JAVA

- Do not create unnecessary objects
- Avoid string concatenation and use String Builder
- Do not store a massive amount of data in the session
- Time out the session when no longer used
- Avoid the use of static objects, as they live for full application life.
	So better set the reference to null explicitly.
- Always close the Result Set, statements and connection objects in finally
	block.