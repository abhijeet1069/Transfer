package com.satyam.interfacesAsTypes.animalTypes;

public interface Mammal{
	public String TYPE = "MAMMAL";
	public String getName();
	public String fact();
}
