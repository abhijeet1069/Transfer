package cleanCode.smells.java.staticImport.good;

import static cleanCode.smells.java.staticImport.good.HttpConstants.GET;

public class InvokeHost {
	public static void invokeGetRequest() {
		
		System.out.println("Invoking "+GET+" request");
	}
	
	public static void main(String[] args) {
		invokeGetRequest();
	}
}
