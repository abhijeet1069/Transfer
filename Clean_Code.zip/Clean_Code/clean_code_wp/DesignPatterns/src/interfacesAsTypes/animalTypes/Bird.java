package interfacesAsTypes.animalTypes;

public interface Bird {
	public String TYPE = "BIRD";
	public String getName();
	public String fact();
}
