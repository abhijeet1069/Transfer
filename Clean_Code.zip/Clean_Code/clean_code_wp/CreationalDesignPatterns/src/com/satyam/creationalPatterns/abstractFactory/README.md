# Abstract Factory

CLearly this is a bigger version of factory method.
You want to create families of related objects, but you don’t want to specify their concrete classes.