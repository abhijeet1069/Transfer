# Ch2 Algorithm Analysis

## Fast exponentiation

Instead of n loops, use number of bits to represent n

Bitwise operators can give high throughput, in fast exponentiation, not only
it gave O(lg n) running time but bitwise as they are implemented in hardware are super fast

## IntToBinary

Good use of bitwise operators