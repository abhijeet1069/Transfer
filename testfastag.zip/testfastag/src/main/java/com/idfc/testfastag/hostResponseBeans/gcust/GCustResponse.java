package com.idfc.testfastag.hostResponseBeans.gcust;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GCustResponse {
	@SerializedName("resCode")
    @Expose
	private String resCode;
	
	@SerializedName("resMsg")
    @Expose
    private String resMsg;
	
	@SerializedName("mobileNo")
    @Expose
    private String mobileNo;
	
	@SerializedName("reqType")
    @Expose
    private String reqType;
	
	@SerializedName("customer")
    @Expose
    private List<Customer> customer;

	public String getResCode() {
		return resCode;
	}

	public void setResCode(String resCode) {
		this.resCode = resCode;
	}

	public String getResMsg() {
		return resMsg;
	}

	public void setResMsg(String resMsg) {
		this.resMsg = resMsg;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public List<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "GCustResponse [resCode=" + resCode + ", resMsg=" + resMsg + ", mobileNo=" + mobileNo + ", reqType="
				+ reqType + ", customer=" + customer + "]";
	}
}
