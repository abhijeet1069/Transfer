# Effective JAVA

This book focuses more on how JAVA can be best put into practice.

## Creating and Destroying objects

### Static Factory Methods

Use static factory methods over constructors : This acts an extra layer over constructors and can manipulate how we use them.
For ex : Singleton

```java
//driver code
// Direct constructor not called. Static method used

User medusa = User.createObjectWithDefaultEmail("Medusa", "Sarpedon Island");
```

### Builder Pattern

The Builder pattern is a good choice when designing classes whose constructors or static factories would have more than a handful of
parameters, especially if many of the parameters are optional or of identical type.

```java
//driver code
// Great way to create objects with multiple required and optional patterns

NutritionFacts cocaCola = new NutritionFacts.Builder(1000, 2).calories(100).sodium(35).build();

```

### Dependency Injection

Pass the resource into the constructor when creating a new instance. Creates loose coupling and is always used.

```java
//driver code

ClassB classB = new ClassB();
ClassA classA = new ClassA(classB); //dependency injected
```

### Avoid creating unnecessary objects

